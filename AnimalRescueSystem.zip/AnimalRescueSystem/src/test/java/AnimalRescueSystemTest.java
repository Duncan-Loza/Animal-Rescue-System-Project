package com.mycompany.animalrescuesystem;

import org.junit.Test;
import static org.junit.Assert.*;

public class AnimalRescueSystemTest {

    @Test
    public void testRescueCostCalculation() {

        InjuredAnimalRescue rescue =
                new InjuredAnimalRescue(
                        "WR101",
                        "African Elephant",
                        "Kruger National Park",
                        "John",
                        "Severe leg injury",
                        15500,
                        true
                );

        assertEquals(
                20500.0,
                rescue.calculateTotalRescueCost(),
                0.01
        );
    }

    @Test
    public void testRescuePriorityCalculation() {

        InjuredAnimalRescue rescue =
                new InjuredAnimalRescue(
                        "WR102",
                        "African Elephant",
                        "Kruger National Park",
                        "John",
                        "Severe leg injury",
                        15500,
                        true
                );

        rescue.calculatePriority();

        assertEquals(
                "Critical",
                rescue.getRescuePriority()
        );
    }

    @Test
    public void testRescueStatusUpdates() {

        InjuredAnimalRescue rescue =
                new InjuredAnimalRescue(
                        "WR103",
                        "Lion",
                        "Limpopo",
                        "David",
                        "Broken leg",
                        5000,
                        false
                );

        assertEquals(
                "Not Started",
                rescue.getCurrentStatus()
        );

        rescue.startRescue();

        assertEquals(
                "Rescue in Progress",
                rescue.getCurrentStatus()
        );

        rescue.completeRescue();

        assertEquals(
                "Completed",
                rescue.getCurrentStatus()
        );
    }

    @Test
    public void testSearchExistingRescueCase() {

        WildlifeRescueManager manager =
                new WildlifeRescueManager();

        InjuredAnimalRescue rescue =
                new InjuredAnimalRescue(
                        "WR104",
                        "Rhino",
                        "Hluhluwe",
                        "Sarah",
                        "Leg injury",
                        8000,
                        false
                );

        rescue.calculatePriority();

        manager.addRescueCase(rescue);

        RescueCase found =
                manager.searchRescueCase("WR104");

        assertNotNull(found);

        assertEquals(
                "WR104",
                found.getRescueCaseId()
        );
    }

    @Test
    public void testPreventDuplicateRescueCaseIds() {

        WildlifeRescueManager manager =
                new WildlifeRescueManager();

        InjuredAnimalRescue firstRescue =
                new InjuredAnimalRescue(
                        "WR105",
                        "Elephant",
                        "Kruger National Park",
                        "John",
                        "Broken leg",
                        5000,
                        false
                );

        InjuredAnimalRescue secondRescue =
                new InjuredAnimalRescue(
                        "WR105",
                        "Lion",
                        "Limpopo",
                        "David",
                        "Injury",
                        4000,
                        false
                );

        boolean firstAdded =
                manager.addRescueCase(firstRescue);

        boolean secondAdded =
                manager.addRescueCase(secondRescue);

        assertTrue(firstAdded);
        assertFalse(secondAdded);
    }
}