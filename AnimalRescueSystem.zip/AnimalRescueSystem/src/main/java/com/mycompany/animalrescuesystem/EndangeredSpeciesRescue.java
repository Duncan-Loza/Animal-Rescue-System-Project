/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 * edit this template
 */
package com.mycompany.animalrescuesystem;

/**
 *
 * @author duncan
 */

public class EndangeredSpeciesRescue extends RescueCase {

    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(String rescueCaseId, String species,
                                   String rescueLocation, String assignedRanger,
                                   String conservationClassification,
                                   double securityCost,
                                   boolean specialistTeamRequired) {

        super(rescueCaseId, species, rescueLocation, assignedRanger);

        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    public String getConservationClassification() {
        return conservationClassification;
    }

    public void setConservationClassification(String conservationClassification) {
        this.conservationClassification = conservationClassification;
    }

    public double getSecurityCost() {
        return securityCost;
    }

    public void setSecurityCost(double securityCost) {
        this.securityCost = securityCost;
    }

    public boolean isSpecialistTeamRequired() {
        return specialistTeamRequired;
    }

    public void setSpecialistTeamRequired(boolean specialistTeamRequired) {
        this.specialistTeamRequired = specialistTeamRequired;
    }

    @Override
    public double calculateTotalRescueCost() {

        double totalCost = securityCost;

        if (specialistTeamRequired) {
            totalCost += 8000;
        }

        return totalCost;
    }

    @Override
    public void calculatePriority() {

        if (specialistTeamRequired) {
            setRescuePriority("Critical");
        } else {
            setRescuePriority("High");
        }
    }

    @Override
    public void startRescue() {

        setCurrentStatus("Rescue in Progress");
    }

    @Override
    public void completeRescue() {

        setCurrentStatus("Completed");
    }

    @Override
    public String generateSummary() {

        return "Rescue Case ID: " + getRescueCaseId()
                + "\nRescue Type: Endangered Species Rescue"
                + "\nSpecies: " + getSpecies()
                + "\nAssigned Ranger: " + getAssignedRanger()
                + "\nRescue Priority: " + getRescuePriority()
                + "\nCurrent Status: " + getCurrentStatus()
                + "\nConservation Classification: " + conservationClassification
                + "\nSecurity Cost: R" + securityCost
                + "\nSpecialist Team Required: " + specialistTeamRequired
                + "\nTotal Rescue Cost: R" + calculateTotalRescueCost();
    }
}