/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.animalrescuesystem;

/**
 *
 * @author duncan
 */

public class OrphanedAnimalRescue extends RescueCase {

    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    public OrphanedAnimalRescue(String rescueCaseId, String species,
                                String rescueLocation, String assignedRanger,
                                int estimatedAgeMonths,
                                double feedingCost,
                                boolean fosterCareRequired) {

        super(rescueCaseId, species, rescueLocation, assignedRanger);

        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    public int getEstimatedAgeMonths() {
        return estimatedAgeMonths;
    }

    public void setEstimatedAgeMonths(int estimatedAgeMonths) {
        this.estimatedAgeMonths = estimatedAgeMonths;
    }

    public double getFeedingCost() {
        return feedingCost;
    }

    public void setFeedingCost(double feedingCost) {
        this.feedingCost = feedingCost;
    }

    public boolean isFosterCareRequired() {
        return fosterCareRequired;
    }

    public void setFosterCareRequired(boolean fosterCareRequired) {
        this.fosterCareRequired = fosterCareRequired;
    }

    @Override
    public double calculateTotalRescueCost() {

        double totalCost = feedingCost;

        if (fosterCareRequired) {
            totalCost += 2500;
        }

        return totalCost;
    }

    @Override
    public void calculatePriority() {

        if (estimatedAgeMonths <= 6 || fosterCareRequired) {
            setRescuePriority("High");
        } else {
            setRescuePriority("Moderate");
        }
    }

    @Override
    public void startRescue() {

        setCurrentStatus("Rescue in Progress");
    }

    @Override
    public void completeRescue() {

        setCurrentStatus("Completed");
    }

    @Override
    public String generateSummary() {

        return "Rescue Case ID: " + getRescueCaseId()
                + "\nRescue Type: Orphaned Animal Rescue"
                + "\nSpecies: " + getSpecies()
                + "\nAssigned Ranger: " + getAssignedRanger()
                + "\nRescue Priority: " + getRescuePriority()
                + "\nCurrent Status: " + getCurrentStatus()
                + "\nEstimated Age: " + estimatedAgeMonths + " months"
                + "\nFeeding Cost: R" + feedingCost
                + "\nFoster Care Required: " + fosterCareRequired
                + "\nTotal Rescue Cost: R" + calculateTotalRescueCost();
    }
}