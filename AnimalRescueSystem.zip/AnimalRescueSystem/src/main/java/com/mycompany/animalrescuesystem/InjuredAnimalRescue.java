/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.animalrescuesystem;

/**
 *
 * @author duncan
 */

public class InjuredAnimalRescue extends RescueCase {

    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    public InjuredAnimalRescue(String rescueCaseId, String species,
                               String rescueLocation, String assignedRanger,
                               String injuryDescription,
                               double veterinaryTreatmentCost,
                               boolean surgeryRequired) {

        super(rescueCaseId, species, rescueLocation, assignedRanger);

        this.injuryDescription = injuryDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    public String getInjuryDescription() {
        return injuryDescription;
    }

    public void setInjuryDescription(String injuryDescription) {
        this.injuryDescription = injuryDescription;
    }

    public double getVeterinaryTreatmentCost() {
        return veterinaryTreatmentCost;
    }

    public void setVeterinaryTreatmentCost(double veterinaryTreatmentCost) {
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
    }

    public boolean isSurgeryRequired() {
        return surgeryRequired;
    }

    public void setSurgeryRequired(boolean surgeryRequired) {
        this.surgeryRequired = surgeryRequired;
    }

    @Override
    public double calculateTotalRescueCost() {

        double totalCost = veterinaryTreatmentCost;

        if (surgeryRequired) {
            totalCost += 5000;
        }

        return totalCost;
    }

    @Override
    public void calculatePriority() {

        if (surgeryRequired) {
            setRescuePriority("Critical");
        } else {
            setRescuePriority("High");
        }
    }

    @Override
    public void startRescue() {

        setCurrentStatus("Rescue in Progress");
    }

    @Override
    public void completeRescue() {

        setCurrentStatus("Completed");
    }

    @Override
    public String generateSummary() {

        return "Rescue Case ID: " + getRescueCaseId()
                + "\nRescue Type: Injured Animal Rescue"
                + "\nSpecies: " + getSpecies()
                + "\nAssigned Ranger: " + getAssignedRanger()
                + "\nRescue Priority: " + getRescuePriority()
                + "\nCurrent Status: " + getCurrentStatus()
                + "\nInjury Description: " + injuryDescription
                + "\nVeterinary Treatment Cost: R" + veterinaryTreatmentCost
                + "\nSurgery Required: " + surgeryRequired
                + "\nTotal Rescue Cost: R" + calculateTotalRescueCost();
    }
}