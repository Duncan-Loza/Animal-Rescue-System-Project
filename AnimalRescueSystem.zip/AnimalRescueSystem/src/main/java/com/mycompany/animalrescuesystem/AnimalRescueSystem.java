/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt
 */

package com.mycompany.animalrescuesystem;

import java.util.Scanner;

public class AnimalRescueSystem {

    private static Scanner scanner = new Scanner(System.in);
    private static WildlifeRescueManager manager = new WildlifeRescueManager();

    public static void main(String[] args) {

        boolean running = true;

        while (running) {

            displayMenu();

            int choice = getMenuChoice();

            switch (choice) {

                case 1:
                    addRescueCase();
                    break;

                case 2:
                    searchCase();
                    break;

                case 3:
                    updateCase();
                    break;

                case 4:
                    startRescue();
                    break;

                case 5:
                    completeRescue();
                    break;

                case 6:
                    monitorProgress();
                    break;

                case 7:
                    manager.generateReport();
                    break;

                case 8:
                    running = false;
                    System.out.println("Exiting Wildlife Rescue System.");
                    break;

                default:
                    System.out.println("Invalid menu choice.");
            }
        }
    }

    // Displays the main menu
    public static void displayMenu() {

        System.out.println();
        System.out.println("======================================");
        System.out.println("       WILDLIFE RESCUE SYSTEM");
        System.out.println("======================================");
        System.out.println("1. Add Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Case");
        System.out.println("4. Start Rescue");
        System.out.println("5. Complete Rescue");
        System.out.println("6. Monitor Rescue Progress");
        System.out.println("7. Generate Rescue Report");
        System.out.println("8. Exit");
        System.out.println("======================================");
    }

    // Gets a valid menu choice
    public static int getMenuChoice() {

        while (true) {

            System.out.print("Enter your choice: ");
            String input = scanner.nextLine().trim();

            try {

                int choice = Integer.parseInt(input);

                if (choice >= 1 && choice <= 8) {
                    return choice;
                }

                System.out.println("Please enter a number between 1 and 8.");

            } catch (NumberFormatException e) {

                System.out.println("Please enter a valid number.");
            }
        }
    }

    // Adds a new rescue case
    public static void addRescueCase() {

        System.out.println();
        System.out.println("======================================");
        System.out.println("         ADD RESCUE CASE");
        System.out.println("======================================");

        String rescueCaseId;

        // Makes sure the Case ID is not blank and is unique
        while (true) {

            rescueCaseId = getRequiredText("Enter Case ID: ");

            if (manager.searchRescueCase(rescueCaseId) == null) {
                break;
            }

            System.out.println("Case ID already exists. Please enter a different Case ID.");
        }

        String species = getRequiredText("Enter species: ");
        String rescueLocation = getRequiredText("Enter rescue location: ");
        String assignedRanger = getRequiredText("Enter assigned ranger: ");

        int rescueType = getRescueTypeChoice();

        RescueCase rescueCase;

        switch (rescueType) {

            case 1:

                String injuryDescription =
                        getRequiredText("Enter injury description: ");

                double veterinaryTreatmentCost =
                        getPositiveDouble("Enter veterinary treatment cost: ");

                boolean surgeryRequired =
                        getYesNo("Is surgery required? (yes/no): ");

                rescueCase = new InjuredAnimalRescue(
                        rescueCaseId,
                        species,
                        rescueLocation,
                        assignedRanger,
                        injuryDescription,
                        veterinaryTreatmentCost,
                        surgeryRequired
                );

                break;

            case 2:

                int estimatedAgeMonths =
                        getPositiveInteger("Enter estimated age in months: ");

                double feedingCost =
                        getPositiveDouble("Enter feeding cost: ");

                boolean fosterCareRequired =
                        getYesNo("Is foster care required? (yes/no): ");

                rescueCase = new OrphanedAnimalRescue(
                        rescueCaseId,
                        species,
                        rescueLocation,
                        assignedRanger,
                        estimatedAgeMonths,
                        feedingCost,
                        fosterCareRequired
                );

                break;

            case 3:

                String conservationClassification =
                        getRequiredText("Enter conservation classification: ");

                double securityCost =
                        getPositiveDouble("Enter security cost: ");

                boolean specialistTeamRequired =
                        getYesNo("Is a specialist team required? (yes/no): ");

                rescueCase = new EndangeredSpeciesRescue(
                        rescueCaseId,
                        species,
                        rescueLocation,
                        assignedRanger,
                        conservationClassification,
                        securityCost,
                        specialistTeamRequired
                );

                break;

            default:

                System.out.println("Invalid rescue type.");
                return;
        }

        // Calculates the priority using the correct subclass method
        rescueCase.calculatePriority();

        boolean added = manager.addRescueCase(rescueCase);

        if (added) {

            System.out.println();
            System.out.println("Rescue case added successfully.");
            System.out.println("Case ID: " + rescueCase.getRescueCaseId());
            System.out.println("Species: " + rescueCase.getSpecies());
            System.out.println("Priority: " + rescueCase.getRescuePriority());
            System.out.println("Status: " + rescueCase.getCurrentStatus());

        } else {

            System.out.println("Rescue case could not be added.");
        }
    }

    // Gets the type of rescue case
    public static int getRescueTypeChoice() {

        while (true) {

            System.out.println();
            System.out.println("Select Rescue Type:");
            System.out.println("1. Injured Animal Rescue");
            System.out.println("2. Orphaned Animal Rescue");
            System.out.println("3. Endangered Species Rescue");

            System.out.print("Enter rescue type: ");

            String input = scanner.nextLine().trim();

            try {

                int choice = Integer.parseInt(input);

                if (choice >= 1 && choice <= 3) {
                    return choice;
                }

                System.out.println("Please enter a number between 1 and 3.");

            } catch (NumberFormatException e) {

                System.out.println("Please enter a valid number.");
            }
        }
    }

    // Gets a Yes or No answer
    public static boolean getYesNo(String message) {

        while (true) {

            System.out.print(message);

            String input = scanner.nextLine().trim();

            if (input.equalsIgnoreCase("yes")
                    || input.equalsIgnoreCase("y")) {

                return true;
            }

            if (input.equalsIgnoreCase("no")
                    || input.equalsIgnoreCase("n")) {

                return false;
            }

            System.out.println("Please enter yes or no.");
        }
    }

    // Searches for a rescue case
    public static void searchCase() {

        String rescueCaseId = getRequiredText("Enter Case ID: ");

        RescueCase rescueCase = manager.searchRescueCase(rescueCaseId);

        if (rescueCase != null) {

            System.out.println();
            System.out.println("Rescue case found.");
            System.out.println("Case ID: " + rescueCase.getRescueCaseId());
            System.out.println("Species: " + rescueCase.getSpecies());
            System.out.println("Rescue Location: " + rescueCase.getRescueLocation());
            System.out.println("Assigned Ranger: " + rescueCase.getAssignedRanger());
            System.out.println("Rescue Priority: " + rescueCase.getRescuePriority());
            System.out.println("Current Status: " + rescueCase.getCurrentStatus());

        } else {

            System.out.println("Rescue case not found.");
        }
    }

    // Updates a rescue case
    public static void updateCase() {

        String rescueCaseId = getRequiredText("Enter Case ID: ");

        RescueCase existingCase = manager.searchRescueCase(rescueCaseId);

        if (existingCase == null) {

            System.out.println("Rescue case not found.");
            return;
        }

        System.out.println("Enter the updated information.");

        String species = getRequiredText("Enter species: ");
        String rescueLocation = getRequiredText("Enter rescue location: ");
        String assignedRanger = getRequiredText("Enter assigned ranger: ");
        String rescuePriority = getRequiredText("Enter rescue priority: ");

        boolean updated = manager.updateRescueCase(
                rescueCaseId,
                species,
                rescueLocation,
                assignedRanger,
                rescuePriority
        );

        if (updated) {
            System.out.println("Rescue case updated successfully.");
        } else {
            System.out.println("Rescue case could not be updated.");
        }
    }

    // Starts a rescue
    public static void startRescue() {

        String rescueCaseId = getRequiredText("Enter Case ID: ");

        boolean started = manager.startRescue(rescueCaseId);

        if (started) {
            System.out.println("Rescue started successfully.");
        } else {
            System.out.println("Rescue case not found.");
        }
    }

    // Completes a rescue
    public static void completeRescue() {

        String rescueCaseId = getRequiredText("Enter Case ID: ");

        boolean completed = manager.completeRescue(rescueCaseId);

        if (completed) {
            System.out.println("Rescue completed successfully.");
        } else {
            System.out.println("Rescue case not found.");
        }
    }

    // Monitors rescue progress
    public static void monitorProgress() {

        String rescueCaseId = getRequiredText("Enter Case ID: ");

        boolean found = manager.monitorRescueProgress(rescueCaseId);

        if (!found) {
            System.out.println("Rescue case not found.");
        }
    }

    // Gets a non-blank String from the user
    public static String getRequiredText(String message) {

        while (true) {

            System.out.print(message);

            String input = scanner.nextLine().trim();

            if (!input.isEmpty()) {
                return input;
            }

            System.out.println("Input cannot be blank. Please try again.");
        }
    }

    // Gets a positive integer from the user
    public static int getPositiveInteger(String message) {

        while (true) {

            System.out.print(message);

            String input = scanner.nextLine().trim();

            try {

                int number = Integer.parseInt(input);

                if (number > 0) {
                    return number;
                }

                System.out.println("Value must be greater than 0.");

            } catch (NumberFormatException e) {

                System.out.println("Please enter a valid number.");
            }
        }
    }

    // Gets a positive decimal number from the user
    public static double getPositiveDouble(String message) {

        while (true) {

            System.out.print(message);

            String input = scanner.nextLine().trim();

            try {

                double number = Double.parseDouble(input);

                if (number > 0) {
                    return number;
                }

                System.out.println("Value must be greater than 0.");

            } catch (NumberFormatException e) {

                System.out.println("Please enter a valid number.");
            }
        }
    }
}