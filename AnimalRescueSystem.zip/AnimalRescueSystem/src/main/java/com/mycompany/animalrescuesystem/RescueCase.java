package com.mycompany.animalrescuesystem;

/**
 *
 * @author duncan
 */
public abstract class RescueCase implements RescueOperations {

    private String rescueCaseId;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private String rescuePriority;
    private String currentStatus;

    public RescueCase(String rescueCaseId, String species, String rescueLocation,
                      String assignedRanger) {

        this.rescueCaseId = rescueCaseId;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.currentStatus = "Not Started";
    }

    public String getRescueCaseId() {
        return rescueCaseId;
    }

    public void setRescueCaseId(String rescueCaseId) {
        this.rescueCaseId = rescueCaseId;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public void setRescueLocation(String rescueLocation) {
        this.rescueLocation = rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public void setAssignedRanger(String assignedRanger) {
        this.assignedRanger = assignedRanger;
    }

    public String getRescuePriority() {
        return rescuePriority;
    }

    public void setRescuePriority(String rescuePriority) {
        this.rescuePriority = rescuePriority;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    // Abstract methods that must be implemented by child classes
    @Override
    public abstract void startRescue();

    @Override
    public abstract void completeRescue();

    @Override
    public abstract String generateSummary();

    public abstract double calculateTotalRescueCost();

    public abstract void calculatePriority();
}