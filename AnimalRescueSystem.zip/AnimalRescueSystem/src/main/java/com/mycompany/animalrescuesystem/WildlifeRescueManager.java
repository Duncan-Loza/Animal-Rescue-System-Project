package com.mycompany.animalrescuesystem;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

/**
 *
 * @author duncan
 */
public class WildlifeRescueManager {

    private ArrayList<RescueCase> rescueCases;

    public WildlifeRescueManager() {
        rescueCases = new ArrayList<>();
    }

    // Adds a new rescue case if the Case ID is unique
    public boolean addRescueCase(RescueCase rescueCase) {

        if (searchRescueCase(rescueCase.getRescueCaseId()) != null) {
            return false;
        }

        rescueCases.add(rescueCase);
        return true;
    }

    // Searches for a rescue case using the Case ID
    public RescueCase searchRescueCase(String rescueCaseId) {

        for (RescueCase rescueCase : rescueCases) {

            if (rescueCase.getRescueCaseId().equalsIgnoreCase(rescueCaseId)) {
                return rescueCase;
            }
        }

        return null;
    }

    // Updates the common information of an existing rescue case
    public boolean updateRescueCase(String rescueCaseId,
                                    String species,
                                    String rescueLocation,
                                    String assignedRanger,
                                    String rescuePriority) {

        RescueCase rescueCase = searchRescueCase(rescueCaseId);

        if (rescueCase != null) {

            rescueCase.setSpecies(species);
            rescueCase.setRescueLocation(rescueLocation);
            rescueCase.setAssignedRanger(assignedRanger);
            rescueCase.setRescuePriority(rescuePriority);

            return true;
        }

        return false;
    }

    // Starts a rescue case
    public boolean startRescue(String rescueCaseId) {

        RescueCase rescueCase = searchRescueCase(rescueCaseId);

        if (rescueCase != null) {
            rescueCase.startRescue();
            return true;
        }

        return false;
    }

    // Completes a rescue case
    public boolean completeRescue(String rescueCaseId) {

        RescueCase rescueCase = searchRescueCase(rescueCaseId);

        if (rescueCase != null) {
            rescueCase.completeRescue();
            return true;
        }

        return false;
    }

    // Displays the current progress of a rescue case
    public boolean monitorRescueProgress(String rescueCaseId) {

        RescueCase rescueCase = searchRescueCase(rescueCaseId);

        if (rescueCase != null) {

            System.out.println();
            System.out.println("======================================");
            System.out.println("       RESCUE PROGRESS");
            System.out.println("======================================");
            System.out.println("Case ID: " + rescueCase.getRescueCaseId());
            System.out.println("Species: " + rescueCase.getSpecies());
            System.out.println("Rescue Location: " + rescueCase.getRescueLocation());
            System.out.println("Assigned Ranger: " + rescueCase.getAssignedRanger());
            System.out.println("Rescue Priority: " + rescueCase.getRescuePriority());
            System.out.println("Current Status: " + rescueCase.getCurrentStatus());
            System.out.println("Total Rescue Cost: R"
                    + formatCurrency(rescueCase.calculateTotalRescueCost()));
            System.out.println("======================================");

            return true;
        }

        return false;
    }

    // Generates a report containing all rescue cases
    public void generateReport() {

        System.out.println();
        System.out.println("======================================");
        System.out.println("       WILDLIFE RESCUE REPORT");
        System.out.println("======================================");

        if (rescueCases.isEmpty()) {
            System.out.println("No rescue cases have been recorded.");
            return;
        }

        double totalRescueCost = 0;

        for (RescueCase rescueCase : rescueCases) {

            System.out.println();
            System.out.println("Case ID: " + rescueCase.getRescueCaseId());
            System.out.println("Rescue Type: " + getRescueType(rescueCase));
            System.out.println("Species: " + rescueCase.getSpecies());
            System.out.println("Rescue Location: " + rescueCase.getRescueLocation());
            System.out.println("Assigned Ranger: " + rescueCase.getAssignedRanger());
            System.out.println("Rescue Priority: " + rescueCase.getRescuePriority());
            System.out.println("Current Status: " + rescueCase.getCurrentStatus());
            System.out.println("Total Rescue Cost: R"
                    + formatCurrency(rescueCase.calculateTotalRescueCost()));

            totalRescueCost += rescueCase.calculateTotalRescueCost();

            System.out.println("--------------------------------------");
        }

        System.out.println();
        System.out.println("Total Cases: " + rescueCases.size());
        System.out.println("Total Rescue Cost: R"
                + formatCurrency(totalRescueCost));
        System.out.println("======================================");
    }

    // Gets the correct display name for each rescue type
    private String getRescueType(RescueCase rescueCase) {

        if (rescueCase instanceof InjuredAnimalRescue) {
            return "Injured Animal Rescue";
        }

        if (rescueCase instanceof OrphanedAnimalRescue) {
            return "Orphaned Animal Rescue";
        }

        if (rescueCase instanceof EndangeredSpeciesRescue) {
            return "Endangered Species Rescue";
        }

        return "Unknown Rescue Type";
    }

    // Formats money values with commas and two decimal places
    private String formatCurrency(double amount) {

        NumberFormat currencyFormat =
                NumberFormat.getNumberInstance(Locale.US);

        currencyFormat.setMinimumFractionDigits(2);
        currencyFormat.setMaximumFractionDigits(2);

        return currencyFormat.format(amount);
    }
}